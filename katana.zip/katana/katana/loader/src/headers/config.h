#pragma once

#define HTTP_SERVER "142.93.97.72"
#define HTTP_PORT 80

#define TFTP_SERVER "142.93.97.72"
