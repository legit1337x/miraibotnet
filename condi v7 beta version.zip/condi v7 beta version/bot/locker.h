#pragma once

void locker_kill(void);
void locker_init(void);
