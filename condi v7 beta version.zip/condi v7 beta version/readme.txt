Real Condi version 7 leaked by @ack_flood
I think the condi version 7 is shit
The Condi Version 7 based on Busybot
The zxcr9999(condi creater is scammer)

The condi version 7 have a lot of bug. I tried to contact zxcr9999. He saw my message, but he didn't reply to me and kicked me out of the group.

Version 7 bug:
The bot cannot be connected(main)