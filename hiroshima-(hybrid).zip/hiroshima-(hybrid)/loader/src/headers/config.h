#pragma once

#define HTTP_SERVER "91.229.239.77"
#define HTTP_PORT 80

#define TFTP_SERVER "91.229.239.77"
